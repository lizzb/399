'use strict';

/* Controllers */

/*
var data = $http.get('phones/full-phones.json');

var fullList = function($scope, $http) {
    $http.get('phones/full-phones.json').success(function(data) {
      $scope.phones = data;
    });*/

var phonecatControllers = angular.module('phonecatControllers', []);

phonecatControllers.controller('PhoneListCtrl', ['$scope', '$http',
  function($scope, $http) {
    $http.get('phones/full-phones.json').success(function(data) {
      $scope.phones = data;
    });

    $scope.orderProp = 'age';
  }]);


phonecatControllers.controller('PhoneDetailCtrl', ['$scope', '$routeParams', '$http',
  function($scope, $routeParams, $http) {
    //$scope.phone = $routeParams.phoneId;
    /*angular.forEach(data, function(item) {
          	if (item.id == $routeParams.phoneId) 
            	$scope.phone = item;
    */
    $http.get('phones/full-phones.json').success(function(data){
        
        angular.forEach(data, function(item) {
          if (item.id == $routeParams.phoneId) 
          {
            $scope.phone = item;
            $scope.mainImageUrl = item.images[0];
          }    
        });

        $scope.setImage = function(imageUrl) {
      $scope.mainImageUrl = imageUrl;
       
      }
    });
     
  }]);


// positive theres a more efficient way to do this....
/*
phonecatControllers.controller('PhoneDetailCtrl', ['$scope', '$routeParams', '$http',
	function($scope, $routeParams, $http) {
    	$http.get('phones/full-phones.json').success(function(data){
        	angular.forEach(data, function(item) {
          	if (item.id == $routeParams.phoneId) 
            	$scope.phone = item;
        });
    });
    }]);
*/
// http://stackoverflow.com/questions/14857739/angular-js-detailed-view-with-only-one-json


/*
phonecatControllers.controller('PhoneDetailCtrl', ['$scope', '$routeParams',
  function($scope, $routeParams) {
    $scope.phoneId = $routeParams.phoneId;
  }]);
*/

/*
Use an Angular filter on your view
(there's no need to filter the data on the service):

<div ng-repeat="entry in playgrounds | filter:{id: 1}">
    <p>properties: {{entry.properties}}</p>
    <p>lat: {{entry.lat}}</p>
    <p>lon: {{entry.lon}}</p>
</div>

	http://jsfiddle.net/bmleite/Ad6u9/
 	
And if you want to filter your view on a $routeParams parameter, 
add this to your controller: 
$scope.myParam = $routeParams.parameterNameFromRouteController; 
and then in your view,
modify the filter to be: 
<div ng-repeat="entry in playgrounds | filter:{id: myParam}"> 
<p>properties: {{entry.properties}}</p> 
<p>lat: {{entry.lat}}</p> 
<p>lon: {{entry.lon}}</p> 
</div> –  Matty J Feb 27 '13 at 3:31

probably not efficient but i'll use this one

function PlaygroundDetailCtrl($scope, $routeParams, $http) {
    $http.get('playgrounds/playgrounds.json').success(function(data){
        angular.forEach(data, function(item) {
          if (item.id == $routeParams.playgroundId) 
            $scope.playground = item;
        });
    });
*/